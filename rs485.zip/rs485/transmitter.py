from machine import UART, Pin, ADC
import time

# Startup blink 5x
led = Pin(25, Pin.OUT)
for _ in range(5):
    led.toggle(); time.sleep(0.15)

uart = UART(1, baudrate=9600, tx=Pin(8), rx=Pin(9))  # GP8/GP9 = PIN11/12
Pin(13, Pin.OUT, value=1)  # DE/RE -> HIGH = always transmit

pot = ADC(Pin(26))         # GP26 = PIN32

while True:
    v = pot.read_u16()     # 0..65535
    uart.write(str(v) + "\n")
    time.sleep_ms(50)
