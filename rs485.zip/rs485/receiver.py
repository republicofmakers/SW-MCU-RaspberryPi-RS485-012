from machine import UART, Pin, PWM
import time

# Startup blink 5x
led_ok = Pin(25, Pin.OUT)
for _ in range(5):
    led_ok.toggle(); time.sleep(0.15)

uart = UART(1, baudrate=9600, tx=Pin(8), rx=Pin(9))
Pin(13, Pin.OUT, value=0)  # DE/RE -> LOW = always receive

pwm = PWM(Pin(12))         # GP12 = PIN16
pwm.freq(1000)

while True:
    line = uart.readline()
    if not line:
        continue
    try:
        val = int(line.strip())     # handle \r\n
        if val < 0: val = 0
        if val > 65535: val = 65535
        pwm.duty_u16(val)
        # tick onboard LED to show valid packet
        led_ok.toggle(); time.sleep_ms(10); led_ok.toggle()
    except:
        pass
